export { default } from "./ComparisonTable";
