import React from "react";

const ComparisonTable = ({ indicator, products, modules }) => {
  // Find matching product data for each product
  const getProductData = (productId) => {
    const productData = indicator.productData.find(
      (d) => d.productId === productId
    );
    return productData || { modules: {} };
  };

  // Format number for display with 2 decimal places when available
  const formatNumber = (num) => {
    if (num === null || num === undefined) return "N/A";
    return typeof num === "number" ? num.toFixed(2) : num;
  };

  return (
    <div style={{ marginBottom: "2rem" }}>
      <h3 style={{ color: "#90caf9", marginBottom: "0.75rem" }}>
        {indicator.name}
      </h3>

      <div style={{ overflowX: "auto" }}>
        <table
          style={{
            width: "100%",
            borderCollapse: "collapse",
            fontSize: "0.9rem",
            backgroundColor: "#1a1a1a",
            color: "#e0e0e0",
          }}
        >
          <thead>
            <tr>
              <th
                style={{
                  padding: "0.75rem",
                  textAlign: "left",
                  borderBottom: "1px solid #444",
                  backgroundColor: "#2c2c2c",
                }}
              >
                Product
              </th>
              <th
                style={{
                  padding: "0.75rem",
                  textAlign: "left",
                  borderBottom: "1px solid #444",
                  backgroundColor: "#2c2c2c",
                }}
              >
                Unit
              </th>
              {modules.map((module) => (
                <th
                  key={module}
                  style={{
                    padding: "0.75rem",
                    textAlign: "right",
                    borderBottom: "1px solid #444",
                    backgroundColor: "#2c2c2c",
                  }}
                >
                  {module}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {products.map((product, index) => {
              const data = getProductData(product.id);

              return (
                <tr
                  key={product.id}
                  style={{
                    backgroundColor: index % 2 ? "#1e1e1e" : "#1a1a1a",
                  }}
                >
                  <td
                    style={{
                      padding: "0.75rem",
                      borderBottom: "1px solid #333",
                      maxWidth: "200px",
                      whiteSpace: "nowrap",
                      overflow: "hidden",
                      textOverflow: "ellipsis",
                    }}
                  >
                    {product.name}
                  </td>
                  <td
                    style={{
                      padding: "0.75rem",
                      borderBottom: "1px solid #333",
                    }}
                  >
                    {product.unit}
                  </td>
                  {modules.map((module) => (
                    <td
                      key={module}
                      style={{
                        padding: "0.75rem",
                        textAlign: "right",
                        borderBottom: "1px solid #333",
                        backgroundColor: data.modules[module]
                          ? undefined
                          : "#1e1e1e40",
                      }}
                    >
                      {formatNumber(data.modules[module])}
                    </td>
                  ))}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default ComparisonTable;
