export { default } from "./IndicatorSearch";
