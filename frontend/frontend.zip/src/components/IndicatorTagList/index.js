export { default } from "./IndicatorTagList";
