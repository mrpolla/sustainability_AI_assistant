export { default } from "./CompareButton";
