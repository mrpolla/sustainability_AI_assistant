export { default } from "./IndicatorTag";
