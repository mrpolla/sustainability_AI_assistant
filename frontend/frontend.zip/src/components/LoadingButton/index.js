export { default } from "./LoadingButton";
